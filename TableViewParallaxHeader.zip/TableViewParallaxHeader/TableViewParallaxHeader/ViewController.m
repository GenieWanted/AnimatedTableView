//
//  ViewController.m
//  TableViewParallaxHeader
//
//  Created by Raghu on 31/07/16.
//  Copyright © 2016 RaghuVardhan. All rights reserved.
//

#import "ViewController.h"
#import "APParallaxHeader/UIScrollView+APParallaxHeader.h"
@interface ViewController () {
    UIView *headerView;
    CGFloat currentConstant;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) UIImageView *headerImage;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topLayoutConstraint;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    headerView = [[NSBundle mainBundle] loadNibNamed:@"HeaderView" owner:self options:nil].firstObject;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(adjustHeightOfContentView:) name:@"contentOffsetChanged" object:nil];
    NSLog(@"Current Constraint : %f", self.topLayoutConstraint.constant);
    currentConstant = self.topLayoutConstraint.constant;
}

-(void)adjustHeightOfContentView:(NSNotification *)notification {

    CGFloat yContentOffset = [[notification.userInfo objectForKey:@"yPosition"] doubleValue];
    CGFloat constantForTopLayout = self.topLayoutConstraint.constant - yContentOffset;
    self.topLayoutConstraint.constant = self.topLayoutConstraint.constant - yContentOffset;
    // NSLog(@"Top LayoutConstraint : %f", self.topLayoutConstraint.constant);
    if(constantForTopLayout < 60) {
        [UIView animateWithDuration:0.5 delay:0.0 usingSpringWithDamping:15.0 initialSpringVelocity:10.0 options:UIViewAnimationOptionCurveEaseIn animations:^{
            self.topLayoutConstraint.constant = 60;
            
            [self.view layoutIfNeeded];
        } completion:nil];

    }
    if(constantForTopLayout > currentConstant) {
        [UIView animateWithDuration:0.5 delay:0.0 usingSpringWithDamping:15.0 initialSpringVelocity:10.0 options:UIViewAnimationOptionCurveEaseIn animations:^{
            self.topLayoutConstraint.constant = currentConstant;
            [self.view layoutIfNeeded];
        } completion:nil];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
