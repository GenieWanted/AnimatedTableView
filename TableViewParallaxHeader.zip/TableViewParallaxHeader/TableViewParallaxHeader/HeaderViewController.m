//
//  HeaderViewController.m
//  TableViewParallaxHeader
//
//  Created by Raghu on 31/07/16.
//  Copyright © 2016 RaghuVardhan. All rights reserved.
//

#import "HeaderViewController.h"

@interface HeaderViewController () {
    CGFloat currentConstantForHeading;
}
@property (weak, nonatomic) IBOutlet UILabel *instrLabel;
@property (weak, nonatomic) IBOutlet UIView *InnerContainerView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topConstraintForHeading;

@end

@implementation HeaderViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(doAnimation:) name:@"contentOffsetChanged" object:nil];
    currentConstantForHeading = self.topConstraintForHeading.constant;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)doAnimation:(NSNotification *)notification {
    NSLog(@"%f", [[notification.userInfo objectForKey:@"yPosition"] doubleValue]);
    CGFloat yOffset = [[notification.userInfo objectForKey:@"yPosition"] doubleValue];
    CGFloat maxPlacement = self.view.frame.size.height - 60;
    self.topConstraintForHeading.constant = self.topConstraintForHeading.constant + yOffset;
    if(self.topConstraintForHeading.constant > maxPlacement) {
        self.topConstraintForHeading.constant = maxPlacement;
    }
//    if(self.topConstraintForHeading.constant > currentConstantForHeading) {
//        [UIView animateWithDuration:0.5 delay:0.0 usingSpringWithDamping:15.0 initialSpringVelocity:10.0 options:UIViewAnimationOptionCurveEaseIn animations:^{
//            self.topConstraintForHeading.constant = currentConstantForHeading;
//            [self.view layoutIfNeeded];
//        } completion:nil];
//    
//    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
